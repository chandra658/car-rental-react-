# KL DriveNow – React Car Rental Project

## Requirements
- Node.js LTS (install from https://nodejs.org)
- Visual Studio Code

## Run in VS Code
1. Extract `KL-DriveNow-Car-Rental.zip`.
2. Open VS Code → File → Open Folder → choose `KL-DriveNow-Car-Rental`.
3. Open Terminal → New Terminal.
4. Run these commands one at a time:

```bash
npm install
npm run dev
```

5. Open the local URL printed in the terminal (usually http://localhost:5173).

## Demo accounts
- Customer: use any email and a password with at least 4 characters.
- Admin: `admin@drivenow.com` and any password with at least 4 characters.

## Included
- Responsive home page and car listings
- Search and vehicle category filter
- Customer login/demo account
- Booking dates and pickup location
- Demo checkout/payment method selection
- Booking confirmation and booking history
- Admin inventory availability controls and booking overview
- Browser `localStorage` persistence

## Important
This is a front-end student demonstration. Login is not securely authenticated, bookings are stored only in this browser, and payment is simulated. Do not use real passwords or card details. A production system needs a backend, database, secure authentication, payment gateway integration, server-side date/availability validation, and admin authorization.
